import './globals.css';
export const metadata={title:'KARL BUSINESS SERVICES — Diagnostic PME',description:'Diagnostic, organisation et développement des PME avec KARL AI'};
export default function RootLayout({children}){return <html lang="fr"><body>{children}</body></html>}
