# KARL BUSINESS SERVICES — site V1

## Fonctionnalités
- Accueil professionnel
- Questionnaire PME en 7 sections
- Diagnostic automatique par domaine
- Analyse KARL AI via `/api/diagnostic`
- Contact WhatsApp
- Responsive mobile

## Déploiement Vercel
1. Importer ce dossier comme projet Next.js.
2. Ajouter `OPENAI_API_KEY` dans Vercel > Settings > Environment Variables pour activer KARL AI.
3. Déployer.

Sans la clé API, le questionnaire et le diagnostic structurel fonctionnent quand même.
